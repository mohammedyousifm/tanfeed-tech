@extends('front.partials.app')

@section('Content')

    @include('front.partials.hero')

    @include('front.partials.whatsapp')

    @include('front.partials.about')

    @include('front.partials.services')

    @include('front.partials.our-client')

    @include('front.partials.testimonials')

    @include('front.partials.contact')
@endsection