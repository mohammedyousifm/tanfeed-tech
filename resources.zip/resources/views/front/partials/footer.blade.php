<!-- Footer -->
<footer class="bg-gradient-to-r from-yellow-600 to-yellow-200 py-8 text-white">
    <div class="container">
        <div class="border-t border-white border-opacity-20 pt-2 text-center text-sm md:text-base">
            <p>&copy; 2025 تنفيذ تك. جميع الحقوق محفوظة.</p>
        </div>
    </div>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="{{ asset('landing/script.js') }}"></script>