<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="{{ asset('dashboard/script.js') }}"></script>
<script src="{{ asset('dashboard/merchant/script.js') }}"></script>