@extends('dashboard.partials.app')
@section('title', 'لوحة تحكم ')

@section('Content')

    <!-- Stats Cards -->
    @include('dashboard.partials.stats-cards')



@endsection
