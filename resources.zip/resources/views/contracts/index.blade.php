@extends('front.partials.app')
@section('title', 'تحميل وثيقة العقد')

@section('Content')
    <section id="contract"
        class="relative bg-cover p-4 bg-center bg-no-repeat before:content-[''] before:absolute before:inset-0 before:bg-black/50">
        <div class="body-section">
            <div class="max-w-2xl contain bg-white/95 p-6 md:p-10 mx-auto rounded-2xl shadow-lg leading-relaxed">
                <h1 class="text-2xl font-bold text-center text-yellow-700 mb-8">
                    تحميل وثيقة العقد
                </h1>
                <form action="{{ route('contract.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
                    @csrf

                    {{-- <input type="hidden" value="{{ $user->id }}" name="userid"> --}}



                    {{-- File Upload --}}
                    <div>
                        <label for="contract_file" class="block f-12 text-gray-700 font-semibold mb-2">تحميل ملف العقد (PDF,
                            DOCX, JPG)</label>
                        <input type="file" name="contract_file" id="contract_file" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                            class="w-full px-2 py-1 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:outline-none bg-white">
                        <p class="text-sm text-gray-500 f-12 mt-1">الحد الأقصى لحجم الملف: 5MB</p>
                    </div>

                    {{-- Submit --}}
                    <div class="text-center">
                        <button type="submit" class="btn bg-[#1B7A75] hover:bg-[#16615C] text-white f-12  hover-up">
                            تقديم العقد
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>
@endsection

<style>
    #contract {
        margin-top: 5rem;
        height: 100vh;
    }
</style>