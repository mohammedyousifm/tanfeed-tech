@component('mail::message')
# مرحباً {{ $user->name }}

شكراً لتسجيلك في <strong style="color:#1B7A75;">تنفيذ تك</strong> 👋
يرجى الضغط على الزر أدناه لتأكيد بريدك الإلكتروني وتفعيل حسابك.

@component('mail::button', ['url' => $url])
تأكيد البريد الإلكتروني
@endcomponent

> <span style="color:#CF9411;">تنفيذ تك</span> تساعدك في تحصيل فواتيرك المعدومة عبر نظام ذكي لإدارة القضايا القانونية
بكفاءة عالية واحترافية.

تحياتنا،
فريق <span style="color:#1B7A75;">{{ config('app.name') }}</span>
@endcomponent