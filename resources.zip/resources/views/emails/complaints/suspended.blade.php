@component('mail::message')
# تم تعليق الطلب رقم {{ $complaint->serial_number }}

عزيزي {{ $complaint->user->name }},

نود إعلامك بأنه تم **تعليق** طلبك رقم **{{ $complaint->serial_number }}** مؤقتًا.

### 🟠 سبب التعليق:
> {{ $reason }}

سيقوم فريقنا بمراجعة حالتك، وسنتواصل معك قريبًا بعد استكمال المتطلبات اللازمة.

@component('mail::button', ['url' => route('complaints.show', $complaint->id)])
عرض تفاصيل الطلب
@endcomponent

تحياتنا،
فريق <span style="color:#1B7A75;">تنفيذ تك</span>
> <span style="color:#CF9411;">نظام متكامل وذكي لإدارة القضايا القانونية وعمليات التحصيل.</span>
@endcomponent