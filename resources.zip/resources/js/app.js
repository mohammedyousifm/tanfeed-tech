import './bootstrap';
import '../css/app.css';
import '@fortawesome/fontawesome-free/css/all.min.css';


import Alpine from 'alpinejs';
window.Alpine = Alpine;
Alpine.start();


