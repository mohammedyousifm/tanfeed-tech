<?php

namespace App\Http\Controllers\Merchant;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Helpers\Notify;
use Illuminate\Http\Request;
use App\Models\Contract;

class ContractController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        return view(
            'contracts.index',
            compact(
                'user',
            )
        );
    }

    public function store(Request $request)
    {
        // 🔹 Validate the incoming request
        $request->validate([
            'contract_file' => 'required|file|mimes:pdf,doc,docx|max:2048',
        ]);

        try {
            DB::beginTransaction();

            // 🔹 Store file securely in "storage/app/public/contracts"
            $path = $request->file('contract_file')->store('contracts', 'public');

            // 🔹 Create new contract record
            Contract::create([
                'user_id' => auth()->id(),
                'contract_file' => $path,
            ]);

            Notify::sendToRole(
                'lawyer',
                'عقد جديد',
                ' تم إرسال عقد جديد من  التاجر  ' . Auth::user()->name .
                    'رقم التاجر '   . Auth::user()->client_number,
                'contract'
            );

            DB::commit();

            // 🔹 Redirect with success message
            return redirect()
                ->route('merchant.dashboard')
                ->with('success', 'تم رفع العقد بنجاح ✅');
        } catch (\Exception $e) {
            DB::rollBack();

            // Log error for debugging
            Log::error('Contract upload failed', [
                'user_id' => auth()->id(),
                'error' => $e->getMessage(),
            ]);

            // 🔹 Redirect with error message
            return redirect()
                ->back()
                ->with('error', 'حدث خطأ أثناء رفع العقد. حاول مرة أخرى لاحقًا.');
        }
    }
}
